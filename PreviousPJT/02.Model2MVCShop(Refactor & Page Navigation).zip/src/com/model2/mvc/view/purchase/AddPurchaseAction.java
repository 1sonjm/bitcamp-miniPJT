package com.model2.mvc.view.purchase;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model2.mvc.framework.Action;
import com.model2.mvc.service.domain.Purchase;
import com.model2.mvc.service.domain.User;
import com.model2.mvc.service.product.ProductService;
import com.model2.mvc.service.product.impl.ProductServiceImpl;
import com.model2.mvc.service.purchase.PurchaseService;
import com.model2.mvc.service.purchase.impl.PurchaseServiceImpl;

public class AddPurchaseAction extends Action {

	public AddPurchaseAction() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		Purchase purchase = new Purchase();
		//System.out.println("##"+(Product)request.getAttribute("product"));
		//purchase.setPurchaseProd((Product)request.getAttribute("product"));
		//�Ʒ�ó�� �ϸ� input text�� ���� ����ڰ� �ٲ� �� �ִµ� ��� ���� ??
		ProductService prService = new ProductServiceImpl();
		int prodid = Integer.parseInt(request.getParameter("prodId"));
		purchase.setPurchaseProd(prService.getProduct(prodid));
		User user = (User)session.getAttribute("user");
		user.setAddr(request.getParameter("receiverAddr"));
		user.setPhone(request.getParameter("receiverPhone"));
		purchase.setBuyer(user);
		purchase.setPaymentOption(request.getParameter("paymentOption"));
		purchase.setDlvyRequest(request.getParameter("receiverRequest"));
		purchase.setDlvyDate(request.getParameter("receiverDate"));
		
		PurchaseService puService = new PurchaseServiceImpl();
		puService.addPurchase(purchase);
		
		return "redirect:/listPurchase.do";
	}

}
