package com.model2.mvc.framework;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model2.mvc.common.util.HttpUtil;


public class ActionServlet extends HttpServlet {
	
	private RequestMapping mapper;

	@Override
	public void init() throws ServletException {
		super.init();
		String resources=getServletConfig().getInitParameter("resources");
		mapper=RequestMapping.getInstance(resources);
		System.out.println("[ActionServlet] init loadon");
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) {
		
		String url = request.getRequestURI();
		String contextPath = request.getContextPath();
		String path = url.substring(contextPath.length());
		System.out.println(path);
		
		try{
			Action action = mapper.getAction(path);
			action.setServletContext(getServletContext());
			
			String resultPage=action.execute(request, response);
			String result=resultPage.substring(resultPage.indexOf(":")+1);
			if(resultPage.startsWith("forward:")){
				HttpUtil.forward(request, response, result);
				System.out.println("forward:"+result);
			}
			else if(resultPage.startsWith("redirect:")){
				HttpUtil.redirect(response, result);
				System.out.println("redirect:"+result);				
			}else{
				System.out.println("servlet forward/redirect ����");
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}