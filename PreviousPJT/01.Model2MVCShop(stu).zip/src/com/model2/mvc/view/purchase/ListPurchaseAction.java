package com.model2.mvc.view.purchase;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model2.mvc.common.SearchVO;
import com.model2.mvc.framework.Action;
import com.model2.mvc.service.purchase.PurchaseService;
import com.model2.mvc.service.purchase.impl.PurchaseServiceImpl;
import com.model2.mvc.service.purchase.vo.PurchaseVO;
import com.model2.mvc.service.user.vo.UserVO;

public class ListPurchaseAction extends Action {

	public ListPurchaseAction() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("[ListPurchaseAction] start");
		HttpSession session = request.getSession();
		UserVO userVO = (UserVO)session.getAttribute("user");
		SearchVO searchVO = new SearchVO();
		
		int page=1;
		if(request.getParameter("page") != null){
			page=Integer.parseInt(request.getParameter("page"));
		}
		searchVO.setPage(page);
		searchVO.setSearchCondition(request.getParameter("searchCondition"));
		searchVO.setSearchKeyword(request.getParameter("searchKeyword"));
		
		int pageMaxUnit=Integer.parseInt(getServletContext().getInitParameter("pageSize"));
		searchVO.setPageUnit(pageMaxUnit);
		
		PurchaseService service=new PurchaseServiceImpl();
		HashMap<String,Object> map=service.getPurchaseList(searchVO, userVO.getUserId());
		System.out.println("map �����Ϸ�");
		
		int totalCount=(int)map.get("count");
		int totalPage=1;

		totalPage /= pageMaxUnit;
		if(totalCount%pageMaxUnit >0){
			totalPage++;
		}

		searchVO.setTotalCount(totalCount);
		searchVO.setTotalPage(totalPage);
		
		ArrayList<PurchaseVO> list=(ArrayList<PurchaseVO>)map.get("list");
		for(int i=0;i<list.size();i++){
			System.out.println(i+"��° ����� �ֹ���ȣ: "+list.get(i).getTranNo());
		}
		System.out.println(map.get("list"));//TODO ���� �Ѿ���µ� ����
		request.setAttribute("map", map);
		request.setAttribute("searchVO", searchVO);	

		System.out.println("[ListPurchaseAction] end");
		return "forward:/purchase/listPurchase.jsp";
	}

}
