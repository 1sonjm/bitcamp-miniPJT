package com.model2.mvc.service.purchase.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import com.model2.mvc.common.SearchVO;
import com.model2.mvc.common.util.DBUtil;
import com.model2.mvc.service.product.ProductService;
import com.model2.mvc.service.product.impl.ProductServiceImpl;
import com.model2.mvc.service.product.vo.ProductVO;
import com.model2.mvc.service.purchase.vo.PurchaseVO;
import com.model2.mvc.service.user.UserService;
import com.model2.mvc.service.user.impl.UserServiceImpl;
import com.model2.mvc.service.user.vo.UserVO;

public class PurchaseDAO {

	public PurchaseDAO() {
		// TODO Auto-generated constructor stub
	}

	public PurchaseVO findPurchase(int targetNo) throws Exception{
		PurchaseVO purchaseVO = new PurchaseVO();
		return purchaseVO;
	}
	
	public HashMap<String, Object> getPurchaseList(SearchVO searchVO, String buyerId) throws Exception{
		
		UserService usService = new UserServiceImpl();
		UserVO userVO = usService.getUser(buyerId);
		
		ProductService prService = new ProductServiceImpl();
		
		Connection con = DBUtil.getConnection();

		String sql = "SELECT tran_no, prod_no, buyer_id, payment_option, receiver_name, receiver_phone"
					+ ", dlvy_addr, dlvy_request, tran_status_code, order_date, dlvy_date"
					+ " FROM transaction ORDER BY tran_no DESC";
		PreparedStatement stmt = 
				con.prepareStatement(sql
									,ResultSet.TYPE_SCROLL_INSENSITIVE
									,ResultSet.CONCUR_UPDATABLE);
		
		ResultSet rs = stmt.executeQuery();

		rs.last();
		int total = rs.getRow();
		System.out.println("�ο��� ��:" + total);

		HashMap<String, Object> purchaseListMap = new HashMap<String, Object>();
		purchaseListMap.put("count", new Integer(total));

		rs.absolute(searchVO.getPage() * searchVO.getPageUnit() - searchVO.getPageUnit()+1);
		System.out.println("searchVO.getPage():" + searchVO.getPage());
		System.out.println("searchVO.getPageUnit():" + searchVO.getPageUnit());
		
		ArrayList<PurchaseVO> list = new ArrayList<PurchaseVO>();
		if (total > 0) {
			for (int i = 0; i < searchVO.getPageUnit(); i++) {
				PurchaseVO purchaseVO = new PurchaseVO();
				purchaseVO.setBuyer(userVO);
				purchaseVO.setDlvyAddr(rs.getString("dlvy_addr"));
				purchaseVO.setDlvyDate(rs.getString("dlvy_date"));
				purchaseVO.setDlvyRequest(rs.getString("dlvy_request"));
				purchaseVO.setOrderDate(rs.getDate("order_date"));
				purchaseVO.setPaymentOption(rs.getString("payment_option"));
				purchaseVO.setPurchaseProd(prService.getProduct(rs.getInt("prod_no")));
				purchaseVO.setReceiverName(rs.getString("receiver_name"));
				purchaseVO.setReceiverPhone(rs.getString("receiver_phone"));
				purchaseVO.setTranCode(rs.getString("tran_status_code"));
				purchaseVO.setTranNo(rs.getInt("tran_no"));
				list.add(purchaseVO);
				if (!rs.next())
					break;
			}
		}
		System.out.println("list.size() : "+ list.size());
		purchaseListMap.put("list", list);
		System.out.println("map().size() : "+ purchaseListMap.size());

		con.close();
			
		return purchaseListMap;
	}
	
	public HashMap<String, Object> getSaleList(SearchVO searchVO) throws Exception{
		HashMap<String, Object> saleList = new HashMap<String, Object>();
		
		return saleList;
	}
	
	public void insertPurchase(PurchaseVO purchaseVO) throws Exception{
		Connection con = DBUtil.getConnection();
		PreparedStatement pstmt 
			= con.prepareStatement("INSERT INTO transaction(tran_no, prod_no, buyer_id, payment_option, receiver_name"
								+ ", receiver_phone, dlvy_addr, dlvy_request, tran_status_code, order_date, dlvy_date)"
								+ " VALUES (seq_transaction_tran_no.nextval,?,?,?,?,?,?,?,?,SYSDATE,?)");
		pstmt.setInt(1, purchaseVO.getPurchaseProd().getProdNo());
		pstmt.setString(2, purchaseVO.getBuyer().getUserId());
		pstmt.setString(3, purchaseVO.getPaymentOption());
		pstmt.setString(4, purchaseVO.getBuyer().getUserName());
		pstmt.setString(5, purchaseVO.getBuyer().getPhone());
		pstmt.setString(6, purchaseVO.getBuyer().getAddr());
		pstmt.setString(7, purchaseVO.getDlvyRequest());
		pstmt.setString(8, "0");//0-���ſϷ�,1-�����,2-��ۿϷ�	
		pstmt.setString(9, purchaseVO.getDlvyDate());
		
		if(pstmt.executeUpdate()==1){
			System.out.println("insert �Ϸ�");
		}else{
			System.out.println("insert error �߻�");
		}
		
		con.close();
	}
	
	public void updatePurchase(PurchaseVO purchaseVO) throws Exception{
		
	}
	
	public void updateTranCode(PurchaseVO purchaseVO) throws Exception{
		
	}
}
